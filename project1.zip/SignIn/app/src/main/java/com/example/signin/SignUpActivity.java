package com.example.signin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class SignUpActivity extends AppCompatActivity {

    EditText name,date,city,gender,email,password,confirmpassword;
    Button signup;

    private FirebaseAuth mAuth;




    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        name = findViewById(R.id.editTextPersonName);
        date= findViewById(R.id.editTextDate);
        city = findViewById(R.id.editTextPersonName2);
        gender =findViewById(R.id.editTextGender);
        email = findViewById(R.id.editTextEmailAddress);
        password = findViewById(R.id.editTextPassword);
        confirmpassword = findViewById(R.id.editTextTextPassword2);

        signup = findViewById(R.id.buttonSignUp);

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Sname = name.getText().toString();
                String Sdate = date.getText().toString();
                String Scity = city.getText().toString();
                String Sgender = gender.getText().toString();


                String Semail = email.getText().toString();
                String Spassword = password.getText().toString();
                String SCpassword = confirmpassword.getText().toString();

                mAuth = FirebaseAuth.getInstance();

                if(name.length() == 0){
                    name.setError("Enter Name");
                    return;
                }else if(date.length() == 0){
                    date.setError("Enter Date");
                    return;
                }else if(city.length() == 0){
                    city.setError("Enter City");
                    return;
                }else if(email.length() == 0){
                    email.setError("Enter valid EMial");
                    return;
                }

                mAuth.createUserWithEmailAndPassword(Semail,Spassword).addOnCompleteListener(SignUpActivity.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                   if(task.isSuccessful())
                   {
                        Toast.makeText(SignUpActivity.this, "Successful Login", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(SignUpActivity.this,DashboardFragment.class));
                        finish();
                   }else{
                       Toast.makeText(SignUpActivity.this, "Login UnSuccessful", Toast.LENGTH_SHORT).show(); 
                     }
                    }
                });

            }
        });


    }
}